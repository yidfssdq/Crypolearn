export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface Lesson {
  id: string;
  title: string;
  category: string;
  objective: string;
  content: string;
  quiz: QuizQuestion[];
  imageUrl?: string;
  videoUrl?: string; // legacy single video
  videos?: { type: 'intro' | 'demo'; title: string; url: string }[];
  documentation?: { title: string; url: string }[];
  diagramUrl?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  lessons: string[];
}

export interface UserProgress {
  completedLessons: string[];
  quizScores: Record<string, number>;
  level: 'Débutant' | 'Intermédiaire' | 'Expert';
}
